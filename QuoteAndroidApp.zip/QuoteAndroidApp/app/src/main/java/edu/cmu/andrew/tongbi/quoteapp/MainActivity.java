package edu.cmu.andrew.tongbi.quoteapp;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Main Activity for Inspirational Quotes Android App
 * This app allows users to search for inspirational quotes by keyword
 */

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    
    // IMPORTANT: Replace this with your actual Codespaces URL
    // Format: https://your-codespace-name-8080.app.github.dev
    private static final String WEB_SERVICE_URL = "https://YOUR_CODESPACE_URL_HERE/getQuote";
    
    // UI Components (3+ different View types as required)
    private EditText keywordInput;        // EditText View
    private Button searchButton;          // Button View
    private TextView quoteText;           // TextView View
    private TextView authorText;          // TextView View
    private TextView noteText;            // TextView View
    private ProgressBar loadingBar;       // ProgressBar View
    private ImageView quoteIcon;          // ImageView View
    
    private ExecutorService executorService;
    private Handler mainHandler;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize executor service for background tasks
        executorService = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
        
        // Initialize UI components
        keywordInput = findViewById(R.id.keywordInput);
        searchButton = findViewById(R.id.searchButton);
        quoteText = findViewById(R.id.quoteText);
        authorText = findViewById(R.id.authorText);
        noteText = findViewById(R.id.noteText);
        loadingBar = findViewById(R.id.loadingBar);
        quoteIcon = findViewById(R.id.quoteIcon);
        
        // Set up button click listener
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchQuote();
            }
        });
        
        // Show initial message
        quoteText.setText("Enter a keyword and tap 'Get Quote' to find inspirational quotes!");
        authorText.setText("");
        noteText.setText("");
    }
    
    /**
     * Fetch quote from web service in background thread
     */
    private void fetchQuote() {
        final String keyword = keywordInput.getText().toString().trim();
        
        // Validate input (can be empty for random quote)
        if (keyword.length() > 50) {
            Toast.makeText(this, "Keyword is too long (max 50 characters)", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Show loading state
        loadingBar.setVisibility(View.VISIBLE);
        searchButton.setEnabled(false);
        quoteText.setText("Searching for quotes...");
        authorText.setText("");
        noteText.setText("");
        
        // Execute network request in background thread
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Build URL with keyword parameter
                    String urlString = WEB_SERVICE_URL;
                    if (!keyword.isEmpty()) {
                        urlString += "?keyword=" + URLEncoder.encode(keyword, "UTF-8");
                    }
                    
                    // Make HTTP GET request
                    URL url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);
                    
                    int responseCode = connection.getResponseCode();
                    
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        // Read response
                        BufferedReader reader = new BufferedReader(
                            new InputStreamReader(connection.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();
                        
                        // Parse JSON response
                        JsonObject jsonResponse = JsonParser.parseString(response.toString())
                            .getAsJsonObject();
                        
                        final boolean success = jsonResponse.get("success").getAsBoolean();
                        
                        if (success) {
                            final String quote = jsonResponse.get("quote").getAsString();
                            final String author = jsonResponse.get("author").getAsString();
                            final String note = jsonResponse.has("note") ? 
                                jsonResponse.get("note").getAsString() : "";
                            
                            // Update UI on main thread
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    displayQuote(quote, author, note);
                                }
                            });
                        } else {
                            final String error = jsonResponse.has("error") ? 
                                jsonResponse.get("error").getAsString() : 
                                "Unknown error occurred";
                            
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    displayError(error);
                                }
                            });
                        }
                    } else {
                        // Handle HTTP error
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                displayError("Server returned error code: " + responseCode);
                            }
                        });
                    }
                    
                    connection.disconnect();
                    
                } catch (final Exception e) {
                    // Handle network errors
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            displayError("Network error: " + e.getMessage() + 
                                "\n\nMake sure to update WEB_SERVICE_URL in MainActivity.java");
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Display quote on UI (called on main thread)
     */
    private void displayQuote(String quote, String author, String note) {
        loadingBar.setVisibility(View.GONE);
        searchButton.setEnabled(true);
        
        quoteText.setText("\"" + quote + "\"");
        authorText.setText("— " + author);
        
        if (!note.isEmpty()) {
            noteText.setText(note);
            noteText.setVisibility(View.VISIBLE);
        } else {
            noteText.setVisibility(View.GONE);
        }
        
        Toast.makeText(this, "Quote loaded successfully!", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Display error message on UI (called on main thread)
     */
    private void displayError(String error) {
        loadingBar.setVisibility(View.GONE);
        searchButton.setEnabled(true);
        
        quoteText.setText("Error: " + error);
        authorText.setText("");
        noteText.setVisibility(View.GONE);
        
        Toast.makeText(this, "Failed to fetch quote", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Shutdown executor service
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}
