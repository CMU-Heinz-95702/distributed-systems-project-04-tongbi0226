package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Main servlet to handle quote requests from Android app
 * Provides RESTful API endpoint for fetching inspirational quotes
 */

import com.google.gson.JsonObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class QuoteServlet extends HttpServlet {
    private MongoDBManager dbManager;
    
    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize MongoDB connection
        dbManager = new MongoDBManager();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set response type
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        JsonObject responseJson = new JsonObject();
        
        long apiRequestTime = 0;
        long apiResponseTime = 0;
        String keyword = "";
        String userAgent = "";
        String quote = "";
        String author = "";
        boolean apiSuccess = false;
        
        try {
            // Get parameters from request
            keyword = request.getParameter("keyword");
            userAgent = request.getHeader("User-Agent");
            
            // Validate input
            if (keyword == null) {
                keyword = "";
            }
            
            // Sanitize keyword to prevent injection attacks
            keyword = sanitizeInput(keyword);
            
            // Record API request time
            apiRequestTime = System.currentTimeMillis();
            
            // Fetch quote from ZenQuotes API
            JsonObject quoteObj = QuoteService.fetchQuoteByKeyword(keyword);
            
            // Record API response time
            apiResponseTime = System.currentTimeMillis();
            
            // Extract quote and author
            quote = quoteObj.get("q").getAsString();
            author = quoteObj.get("a").getAsString();
            
            // Check if there's a note (keyword not found)
            String note = quoteObj.has("note") ? quoteObj.get("note").getAsString() : "";
            
            apiSuccess = true;
            
            // Build successful response
            responseJson.addProperty("success", true);
            responseJson.addProperty("quote", quote);
            responseJson.addProperty("author", author);
            if (!note.isEmpty()) {
                responseJson.addProperty("note", note);
            }
            responseJson.addProperty("keyword", keyword);
            
            response.setStatus(HttpServletResponse.SC_OK);
            
        } catch (Exception e) {
            // Handle errors
            apiResponseTime = System.currentTimeMillis();
            apiSuccess = false;
            
            System.err.println("Error fetching quote: " + e.getMessage());
            e.printStackTrace();
            
            responseJson.addProperty("success", false);
            responseJson.addProperty("error", "Failed to fetch quote: " + e.getMessage());
            responseJson.addProperty("keyword", keyword);
            
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            
            // Set default values for logging
            quote = "Error occurred";
            author = "N/A";
        } finally {
            // Log the request to MongoDB (only for mobile app requests, not dashboard)
            try {
                dbManager.logRequest(keyword, userAgent, apiRequestTime, 
                                    apiResponseTime, quote, author, apiSuccess);
            } catch (Exception e) {
                System.err.println("Error logging to database: " + e.getMessage());
            }
        }
        
        // Send response
        out.println(responseJson.toString());
        out.flush();
    }
    
    /**
     * Sanitize user input to prevent injection attacks
     */
    private String sanitizeInput(String input) {
        if (input == null) return "";
        // Remove potentially dangerous characters
        return input.replaceAll("[<>\"']", "").trim();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Support POST method as well
        doGet(request, response);
    }
    
    @Override
    public void destroy() {
        // Clean up resources
        if (dbManager != null) {
            dbManager.close();
        }
        super.destroy();
    }
}
