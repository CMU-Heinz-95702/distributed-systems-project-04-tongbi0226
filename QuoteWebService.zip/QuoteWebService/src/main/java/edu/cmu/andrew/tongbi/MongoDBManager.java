package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * MongoDB Database Manager for Quote Application
 * Handles all database operations including logging and analytics
 */

import com.mongodb.client.*;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MongoDBManager {
    private static final String CONNECTION_STRING = 
        "mongodb+srv://tongbi:Bt115226@cluster0.ogbhamt.mongodb.net/?appName=Cluster0";
    private static final String DATABASE_NAME = "quoteapp";
    private static final String COLLECTION_NAME = "logs";
    
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;
    
    /**
     * Constructor - establishes connection to MongoDB
     */
    public MongoDBManager() {
        try {
            mongoClient = MongoClients.create(CONNECTION_STRING);
            database = mongoClient.getDatabase(DATABASE_NAME);
            collection = database.getCollection(COLLECTION_NAME);
            System.out.println("Successfully connected to MongoDB Atlas");
        } catch (Exception e) {
            System.err.println("Error connecting to MongoDB: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Log a request from the mobile app
     * Logs 6+ pieces of information as required:
     * 1. Timestamp
     * 2. User input keyword
     * 3. User device info (User-Agent)
     * 4. Third-party API request time
     * 5. Third-party API response time
     * 6. Quote returned to user
     * 7. Author of the quote
     * 8. API call success/failure status
     */
    public void logRequest(String keyword, String userAgent, 
                          long apiRequestTime, long apiResponseTime,
                          String quote, String author, boolean success) {
        try {
            Document logDoc = new Document()
                .append("timestamp", new Date())
                .append("userKeyword", keyword)
                .append("userAgent", userAgent)
                .append("apiRequestTime", apiRequestTime)
                .append("apiResponseTime", apiResponseTime)
                .append("apiLatency", apiResponseTime - apiRequestTime)
                .append("quoteReturned", quote)
                .append("quoteAuthor", author)
                .append("apiSuccess", success);
            
            collection.insertOne(logDoc);
            System.out.println("Request logged successfully");
        } catch (Exception e) {
            System.err.println("Error logging request: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Get all logs from the database
     */
    public List<Document> getAllLogs() {
        List<Document> logs = new ArrayList<>();
        try {
            FindIterable<Document> documents = collection.find()
                .sort(new Document("timestamp", -1)); // Sort by most recent first
            for (Document doc : documents) {
                logs.add(doc);
            }
        } catch (Exception e) {
            System.err.println("Error retrieving logs: " + e.getMessage());
            e.printStackTrace();
        }
        return logs;
    }
    
    /**
     * Get analytics: Total number of requests
     */
    public long getTotalRequests() {
        try {
            return collection.countDocuments();
        } catch (Exception e) {
            System.err.println("Error counting documents: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Get analytics: Average API latency in milliseconds
     */
    public double getAverageLatency() {
        try {
            List<Document> logs = getAllLogs();
            if (logs.isEmpty()) return 0.0;
            
            long totalLatency = 0;
            for (Document log : logs) {
                Long latency = log.getLong("apiLatency");
                if (latency != null) {
                    totalLatency += latency;
                }
            }
            return (double) totalLatency / logs.size();
        } catch (Exception e) {
            System.err.println("Error calculating average latency: " + e.getMessage());
            return 0.0;
        }
    }
    
    /**
     * Get analytics: Top 5 most searched keywords
     */
    public Map<String, Integer> getTopKeywords() {
        Map<String, Integer> keywordCount = new HashMap<>();
        try {
            List<Document> logs = getAllLogs();
            for (Document log : logs) {
                String keyword = log.getString("userKeyword");
                if (keyword != null && !keyword.isEmpty()) {
                    keywordCount.put(keyword, keywordCount.getOrDefault(keyword, 0) + 1);
                }
            }
        } catch (Exception e) {
            System.err.println("Error getting top keywords: " + e.getMessage());
        }
        return keywordCount;
    }
    
    /**
     * Get analytics: Success rate of API calls
     */
    public double getSuccessRate() {
        try {
            List<Document> logs = getAllLogs();
            if (logs.isEmpty()) return 0.0;
            
            long successCount = 0;
            for (Document log : logs) {
                Boolean success = log.getBoolean("apiSuccess");
                if (success != null && success) {
                    successCount++;
                }
            }
            return (double) successCount / logs.size() * 100;
        } catch (Exception e) {
            System.err.println("Error calculating success rate: " + e.getMessage());
            return 0.0;
        }
    }
    
    /**
     * Get analytics: Most popular quote authors
     */
    public Map<String, Integer> getTopAuthors() {
        Map<String, Integer> authorCount = new HashMap<>();
        try {
            List<Document> logs = getAllLogs();
            for (Document log : logs) {
                String author = log.getString("quoteAuthor");
                if (author != null && !author.isEmpty()) {
                    authorCount.put(author, authorCount.getOrDefault(author, 0) + 1);
                }
            }
        } catch (Exception e) {
            System.err.println("Error getting top authors: " + e.getMessage());
        }
        return authorCount;
    }
    
    /**
     * Close the database connection
     */
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("MongoDB connection closed");
        }
    }
}
