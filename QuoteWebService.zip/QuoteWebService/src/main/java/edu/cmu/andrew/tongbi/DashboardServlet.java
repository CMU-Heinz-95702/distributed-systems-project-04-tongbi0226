package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Dashboard servlet to display analytics and logs
 */

import org.bson.Document;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class DashboardServlet extends HttpServlet {
    private MongoDBManager dbManager;
    
    @Override
    public void init() throws ServletException {
        super.init();
        dbManager = new MongoDBManager();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Get all logs
        List<Document> logs = dbManager.getAllLogs();
        
        // Get analytics
        long totalRequests = dbManager.getTotalRequests();
        double avgLatency = dbManager.getAverageLatency();
        double successRate = dbManager.getSuccessRate();
        
        // Get top 5 keywords
        Map<String, Integer> keywordCounts = dbManager.getTopKeywords();
        List<Map.Entry<String, Integer>> topKeywords = keywordCounts.entrySet()
            .stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .collect(Collectors.toList());
        
        // Get top 5 authors
        Map<String, Integer> authorCounts = dbManager.getTopAuthors();
        List<Map.Entry<String, Integer>> topAuthors = authorCounts.entrySet()
            .stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .collect(Collectors.toList());
        
        // Set attributes for JSP
        request.setAttribute("totalRequests", totalRequests);
        request.setAttribute("avgLatency", String.format("%.2f", avgLatency));
        request.setAttribute("successRate", String.format("%.2f", successRate));
        request.setAttribute("topKeywords", topKeywords);
        request.setAttribute("topAuthors", topAuthors);
        request.setAttribute("logs", logs);
        
        // Forward to JSP
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
    
    @Override
    public void destroy() {
        if (dbManager != null) {
            dbManager.close();
        }
        super.destroy();
    }
}
