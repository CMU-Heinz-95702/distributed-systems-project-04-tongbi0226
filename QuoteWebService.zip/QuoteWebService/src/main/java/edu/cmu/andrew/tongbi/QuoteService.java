package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Service class to fetch quotes from ZenQuotes API
 */

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class QuoteService {
    private static final String ZENQUOTES_API_URL = "https://zenquotes.io/api/random";
    
    /**
     * Fetch a random inspirational quote from ZenQuotes API
     * Returns a JsonObject containing the quote and author
     */
    public static JsonObject fetchRandomQuote() throws Exception {
        URL url = new URL(ZENQUOTES_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new Exception("API returned error code: " + responseCode);
        }
        
        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        conn.disconnect();
        
        // Parse JSON response
        JsonArray jsonArray = JsonParser.parseString(response.toString()).getAsJsonArray();
        if (jsonArray.size() > 0) {
            return jsonArray.get(0).getAsJsonObject();
        } else {
            throw new Exception("No quote returned from API");
        }
    }
    
    /**
     * Filter quote based on keyword - check if quote or author contains the keyword
     * If keyword is empty or null, return any random quote
     * Otherwise, keep fetching until we find a relevant quote (with max attempts)
     */
    public static JsonObject fetchQuoteByKeyword(String keyword) throws Exception {
        if (keyword == null || keyword.trim().isEmpty()) {
            return fetchRandomQuote();
        }
        
        keyword = keyword.trim().toLowerCase();
        int maxAttempts = 10; // Limit attempts to avoid infinite loop
        
        for (int i = 0; i < maxAttempts; i++) {
            JsonObject quoteObj = fetchRandomQuote();
            String quote = quoteObj.get("q").getAsString().toLowerCase();
            String author = quoteObj.get("a").getAsString().toLowerCase();
            
            // Check if keyword appears in quote or author
            if (quote.contains(keyword) || author.contains(keyword)) {
                return quoteObj;
            }
        }
        
        // If no matching quote found after max attempts, return the last fetched quote
        // with a note
        JsonObject result = fetchRandomQuote();
        result.addProperty("note", "No exact match found for '" + keyword + 
                          "', showing a random inspirational quote instead.");
        return result;
    }
}
