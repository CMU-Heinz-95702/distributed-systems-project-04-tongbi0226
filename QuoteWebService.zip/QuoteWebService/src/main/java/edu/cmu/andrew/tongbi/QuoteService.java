package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Service class to fetch quotes from ZenQuotes API
 */

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class QuoteService {
    private static final String ZENQUOTES_API_URL = "https://zenquotes.io/api/random";
    
    // ZenQuotes supported keywords (from their browse keywords page)
    private static final Set<String> SUPPORTED_KEYWORDS = new HashSet<>(Arrays.asList(
        "anxiety", "change", "choice", "confidence", "courage", "death", 
        "dreams", "excellence", "failure", "fairness", "fear", "forgiveness",
        "freedom", "future", "happiness", "inspiration", "kindness", "leadership",
        "life", "living", "love", "pain", "past", "success", 
        "time", "today", "truth", "work"
    ));
    
    /**
     * Fetch a random inspirational quote from ZenQuotes API
     * Returns a JsonObject containing the quote and author
     */
    public static JsonObject fetchRandomQuote() throws Exception {
        URL url = new URL(ZENQUOTES_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new Exception("API returned error code: " + responseCode);
        }
        
        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        conn.disconnect();
        
        // Parse JSON response
        JsonArray jsonArray = JsonParser.parseString(response.toString()).getAsJsonArray();
        if (jsonArray.size() > 0) {
            return jsonArray.get(0).getAsJsonObject();
        } else {
            throw new Exception("No quote returned from API");
        }
    }
    
    /**
     * Fetch quote based on keyword
     * 
     * Strategy:
     * 1. If keyword is in ZenQuotes supported list, return random quote with positive note
     * 2. If keyword is not supported, return random quote with apologetic note
     * 
     * Note: ZenQuotes /api/random endpoint doesn't support keyword filtering.
     * We only call the API ONCE per request to avoid rate limiting (5 req/30s).
     * The keyword validation helps set user expectations appropriately.
     */
    public static JsonObject fetchQuoteByKeyword(String keyword) throws Exception {
        if (keyword == null || keyword.trim().isEmpty()) {
            return fetchRandomQuote();
        }
        
        String normalizedKeyword = keyword.trim().toLowerCase();
        JsonObject result = fetchRandomQuote();
        result.addProperty("keyword", keyword.trim());
        
        // Check if keyword is in ZenQuotes supported list
        if (SUPPORTED_KEYWORDS.contains(normalizedKeyword)) {
            result.addProperty("note", "Inspirational quote about: " + keyword.trim());
        } else {
            result.addProperty("note", "Sorry, our library doesn't have quotes about '" + 
                              keyword.trim() + "'. Here's an inspiring quote for you!");
        }
        
        return result;
    }
}
