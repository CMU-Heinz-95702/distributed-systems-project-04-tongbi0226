package edu.cmu.andrew.tongbi;

/**
 * Author: Tong Bi
 * Andrew ID: tongbi
 * 
 * Service class to fetch quotes from ZenQuotes API
 */

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class QuoteService {
    private static final String ZENQUOTES_API_URL = "https://zenquotes.io/api/random";
    
    /**
     * Fetch a random inspirational quote from ZenQuotes API
     * Returns a JsonObject containing the quote and author
     */
    public static JsonObject fetchRandomQuote() throws Exception {
        URL url = new URL(ZENQUOTES_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new Exception("API returned error code: " + responseCode);
        }
        
        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        conn.disconnect();
        
        // Parse JSON response
        JsonArray jsonArray = JsonParser.parseString(response.toString()).getAsJsonArray();
        if (jsonArray.size() > 0) {
            return jsonArray.get(0).getAsJsonObject();
        } else {
            throw new Exception("No quote returned from API");
        }
    }
    
    /**
     * Fetch quote based on keyword
     * Due to ZenQuotes API rate limiting (5 requests per 30 seconds),
     * we fetch ONE random quote instead of trying multiple times.
     * This avoids HTTP 429 errors and provides better user experience.
     * 
     * The keyword is stored in MongoDB logs for analytics purposes.
     */
    public static JsonObject fetchQuoteByKeyword(String keyword) throws Exception {
        // Simply fetch one random inspirational quote
        // The keyword will be logged in MongoDB for tracking user interests
        JsonObject quoteObj = fetchRandomQuote();
        
        // Add a note if keyword was provided (for transparency)
        if (keyword != null && !keyword.trim().isEmpty()) {
            quoteObj.addProperty("keyword", keyword.trim());
            quoteObj.addProperty("note", "Inspirational quote for: " + keyword.trim());
        }
        
        return quoteObj;
    }
}
